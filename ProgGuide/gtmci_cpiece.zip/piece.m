get(str,delim,start) ; 
   quit $piece(str,delim,start) 
set(str,delim,start,value) ; 
   set $piece(str,delim,start)=value 
   quit 

