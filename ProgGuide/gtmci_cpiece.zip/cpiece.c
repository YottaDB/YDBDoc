/* This program is a driver to demonstrate a C main() program that calls in to GT.M.
   No claim of copyright is made with respect to this code.

   This program is intended to be compatible with versions of GT.M V5.4-002B and higher
   on all POSIX platforms.  It was built and tested on selected platforms as follows.


   SPARC Solaris 10
     /opt/SUNWspro/bin/cc -KPIC -c -D_LARGEFILE64_SOURCE=1 -D_FILE_OFFSET_BITS=64 -DSUNOS -DSHADOWPW -fns -ftrap=%none -fsingle -libmil -xtarget=ultra2 -m64 -xarch=generic -xchip=ultra2 cpiece.c -I$gtm_dist
     /opt/SUNWspro/bin/cc -o cpiece -Wl,-64 -m64 -xarch=generic -fns -ftrap=%none -fsingle cpiece.o -R$gtm_dist -L$gtm_dist -lgtmshr -lcurses -lumem -lm -lsocket -lnsl -lelf -ldl -lposix4 -lresolv
     
   x86 GNU/Linux (64-bit and 32-bit Ubuntu 11.10 & 32-bit RHEL 5.5)
     gcc -c cpiece.c -I$gtm_dist
     gcc cpiece.o -o cpiece -L $gtm_dist -Wl,-rpath=$gtm_dist -lgtmshr

   The expected result of running this program is as follows: 

	scrstr=/usr/lib/gtm/V5.4-002B
	srcstr = /usr/lib/gtm/V5.4-002B
	$piece(/usr/lib/gtm/V5.4-002B,"/",4) is gtm
	After set $piece(srcstr,"/",4) = fis-gtm
	srcstr = /usr/lib/fis-gtm/V5.4-002B
   
   This program is only a demonstration.  Please ensure that you have a correctly
   configured GT.M installation, correctly configured environment variables,
   with appropriate directories and files.

   DO NOT USE THIS CODE AS-IS IN A PRODUCTION ENVIRONMENT.

*/

#include <stdio.h> 
#include "gtmxc_types.h" 
#define BUF_LEN 1024 
int main() 
{ 
   gtm_char_t      msgbuf[BUF_LEN], dststr[100]; 
   gtm_char_t      srcstr[100] = "/usr/lib/gtm/V5.4-002B"; 
   gtm_status_t    status; 
   status = gtm_init(); 
   if (status != 0) 
   { 
            gtm_zstatus(msgbuf, BUF_LEN); 
            return status; 
   } 
   printf("srcstr = %s\n", srcstr); 
   status = gtm_ci("getpiece", dststr, srcstr, "/", 4); 
   if (status != 0) 
   { 
            gtm_zstatus(msgbuf, BUF_LEN); 
            fprintf(stderr, "%s\n", msgbuf); 
            return status; 
   } 
   printf("$piece(%s,\"/\",4) is %s\n", srcstr, dststr); 
   printf("After set $piece(srcstr,\"/\",4) = fis-gtm\n"); 
   status = gtm_ci("setpiece", srcstr, "/", 4, "fis-gtm"); 
   if (status != 0) 
   { 
            gtm_zstatus(msgbuf, BUF_LEN); 
            fprintf(stderr, "%s\n", msgbuf); 
            return status; 
   } 
   printf("srcstr = %s\n", srcstr); 
   status = gtm_exit(); 
   if (status != 0) 
   { 
            gtm_zstatus(msgbuf, BUF_LEN); 
            fprintf(stderr, "%s\n", msgbuf); 
            return status; 
   } 
   return 0; 
}

