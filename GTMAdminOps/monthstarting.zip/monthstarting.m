; No claim of copyright is made with regard to to this code
; 
; Usage: mumps -run day [year1 [year2]]
; Prints months starting with the given day in year1 through year2 (both 1841 through 999999)
; year2 defaults to year1 if zero or not specified
; year1 defaults to current year if zero or not specified
;

monthstarting
	new day
	set day=$piece($zcmdline," ",1)
	if 0=$length(day)!(0'=+day) write "Please at least specify a day",! quit
	zhalt $$calcprint(day,$justify(+$piece($zcmdline," ",2),"",0),$justify(+$piece($zcmdline," ",3),"",0))

calcprint(day,year1,year2)
	new year,month,tmp
	set day=$zconvert($extract($piece(day,"/",$length(day,"/")),1,3),"U")
	if '(day?1(1"SUN",1"MON",1"TUE",1"WED",1"THU",1"FRI",1"SAT")) write day," is not Sunday through Saturday",! quit 2
	set:0=+year1 year1=+$zdate($horolog,"YEAR")
	set:0=+year2 year2=year1
	if (year1<1841)!(year2<1841)!(year1>9999)!(year2>9999) write "Only years 1841 through 9999 are supported",! quit 1
	set:year2<year1 tmp=year2,year2=year1,year1=tmp
	for year=year1:1:year2 for month=1:1:12 do
	. set tmp=$$FUNC^%DATE(month_"/1/"_year)
	. write:day=$zdate(tmp,"DAY") $zdate(tmp,"DAY MON DD, YEAR"),!
	quit 0

