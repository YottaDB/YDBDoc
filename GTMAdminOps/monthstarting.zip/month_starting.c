/* No claim of copyright is made with regard to to this code

   Usage: dayname [year1 [year2]]
   Prints months starting with dayname in year1 through year2 (both 1841 through 999999)
   year2 defaults to year1 if zero or not specified
   year1 defaults to current year if zero or not specified

   Compile per directions for compiling programs calling in to GT.M for your OS, as described
   in the GT.M Programmers Guide UNIX Edition Chapter 11 (Integrating External Routines).
   Install executable as a day of the week name, e.g., friday (first three letters are matter; case-independent)
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include "gtmxc_types.h"

#define MAXSTR 65536
#ifndef NULL
# define NULL ((void *) 0)
#endif


int main (int argc, char *argv[])
{
	gtm_int_t status;
	struct termios stderr_sav, stdin_sav, stdout_sav;
	char strbuf[MAXSTR];
	size_t tmp1, tmp2;

	/* Since GT.M changes the terminal attributes, save the attributes of stderr, stdin and stdout
	   in order to restore them before exit
	*/
	tcgetattr( 0, &stdin_sav );
	tcgetattr( 1, &stdout_sav );
	tcgetattr( 2, &stderr_sav );

	/* Define environment variables if not already defined */
	setenv( "gtm_dist", "/usr/lib/fis-gtm/V6.1-000_x86_64", 0 );
	if (NULL == getenv( "gtmroutines" ))
	{
		tmp1 = strlen( getenv( "PWD" ));
		strncpy( strbuf, getenv( "PWD"), tmp1 );
		strcpy( strbuf+tmp1, " " );
		tmp2 = tmp1+1;
		tmp1 = strlen( getenv( "gtm_dist" ));
		strncpy( strbuf+tmp2, getenv( "gtm_dist" ), tmp1 );
		tmp2 += tmp1;
		if ( 8 == sizeof( char * ))
		{
			tmp1 = strlen( "/libgtmutil.so" );
			strncpy( strbuf+tmp2, "/libgtmutil.so", tmp1 );
			tmp2 += tmp1;
		}
		strcpy( strbuf+tmp2, "" );
		setenv( "gtmroutines", strbuf, 1 );
	}
	setenv( "GTMCI", "monthstarting.ci", 0 );

	if ( 0 == gtm_init() ) gtm_ci("calcprint", &status, argv[0], argc>1 ? argv[1] : "", argc>2 ? argv[2] : "");
	gtm_exit(); /* Discard status from gtm_exit and return status from function call */

	/* Restore terminal attributes & return */
	tcsetattr( 2, 0, &stderr_sav );
	tcsetattr( 1, 0, &stdout_sav );
	tcsetattr( 0, 0, &stdin_sav );
	return status;

}
