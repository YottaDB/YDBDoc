/****************************************************************
 *								*
 * Copyright (c) 2022 Fidelity National Information		*
 * Services, Inc. and/or its subsidiaries. All rights reserved.	*
 *								*
 *	This source code contains the intellectual property	*
 *	of its copyright holder(s), and is made available	*
 *	under a license.  If you do not know the terms of	*
 *	the license, please stop and do not read further.	*
 *								*
 ****************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <errno.h>
#include <sys/stat.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>

#define TIME_FORMAT     "_%Y%j%H%M%S"   /* .yearjuliendayhoursminutesseconds */
int switch_logfile(char *logfile)
{
	int			logfile_len, switchlogfile_len, suffix, logfd, timefmtlen = 101;
        char			time_format[timefmtlen],  switchlogfile[PATH_MAX + 1];
	time_t			switchtime;
	struct tm		*timeptr;
	struct stat     	fs;

	errno = 0;
	time(&switchtime);
	if (0 != errno)
	{
		perror("Error determining switch time");
		return 1;
	}
	timeptr = gmtime(&switchtime);
	memset(time_format, '\0', timefmtlen);
	strftime(time_format, timefmtlen, TIME_FORMAT, timeptr);
	logfile_len = strlen(logfile);
	snprintf(switchlogfile, logfile_len + sizeof(time_format), "%s%s", logfile, time_format);
	switchlogfile_len = strlen(switchlogfile);
	suffix = 1;
	while ((0 == stat(switchlogfile, &fs)) || (ENOENT != errno))  /* This file exists */
	{
		sprintf(&switchlogfile[switchlogfile_len], "_%d", suffix);
		suffix++;
	}
	if ((-1 == rename(logfile, &switchlogfile[0])) || (-1 == (logfd = open(logfile, O_WRONLY | O_CREAT | O_APPEND, S_IWUSR | S_IRUSR))) || (-1 == dup2(logfd, STDERR_FILENO)) || (-1 == dup2(logfd, STDOUT_FILENO)))
	{
		perror("Error switching log file");
		return 1;
	}
	return 0;
}
