/****************************************************************
 *								*
 * Copyright (c) 2018-2019 Fidelity National Information	*
 * Services, Inc. and/or its subsidiaries. All rights reserved.	*
 *								*
 *	This source code contains the intellectual property	*
 *	of its copyright holder(s), and is made available	*
 *	under a license.  If you do not know the terms of	*
 *	the license, please stop and do not read further.	*
 *								*
 ****************************************************************/

#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <time.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>

#define	BUF_SIZE	2048	/* For testing/demo purposes, we'll keep this at a lower number */
#define	BACKLOG		10	/* Maximum length to which the queue of pending connections for socket may grow */
/* Parameter Numbers */
#define	PROGNAME	0
#define	LOGFILE		1
#define	PORTNO		2

char	logfile[PATH_MAX + 1];
int	terminate;		/* Boolean value set by signal handler to let program know to terminate */

/* Handler for SIGINT and SIGTERM caused by Ctrl-C and kill (-15) respectively.
 *
 * params:
 * 	@sig signal number
 *
 * MAINTENANCE NOTE: This function also exists in dm_audit_tls_listener.c and dm_audit_unix_listener.c.
 *	If changes are made here, then they should also be made in the other two programs.
 */
void listener_signal_handler(int sig)
{
	terminate = 1;
	return;
}

/* Opens a file and dup its file descriptor to stdout and stderr
 *
 * params:
 * 	@where file path of output audit log file
 * returns:
 * 	1 if log file opened and dup'ed successfully
 * 	0 if something went wrong
 *
 * MAINTENANCE NOTE: This function also exists in dm_audit_tls_listener.c and dm_audit_unix_listener.c.
 *	If changes are made here, then they should also be made in the other two programs.
 */
int open_logfile(char *where)
{
	int	logfd;

	if (NULL != where)
	{
		memset(logfile, 0, PATH_MAX + 1);
		strncpy(logfile, where, PATH_MAX);
	}
	if (strlen(logfile))
	{
		logfd = open(logfile, O_WRONLY | O_CREAT | O_APPEND, S_IWUSR | S_IRUSR);
		if (0 > logfd)
		{
			fprintf(stderr, "Failed to open output file %s: %s\n", logfile, strerror(errno));
			return 0;
		}
		dup2(logfd, STDOUT_FILENO);
		dup2(logfd, STDERR_FILENO);
		close(logfd);
		return 1;
	}
	fprintf(stderr, "No log file specified.");
	return 0;
}

/* Escapes all backslashes ('\\'), null characters ('\0'), and newlines ('\n')
 *
 * params:
 * 	@source original string (contains at most "maxlen" characters) to escape
 * 	@target dest string that must contain enough space for at least 2 * "maxlen" characters (if all characters must be escaped)
 * 	@maxlen length of "source" string
 *
 * MAINTENANCE NOTE: This function also exists in dm_audit_tls_listener.c and dm_audit_unix_listener.c.
 *	If changes are made here, then they should also be made in the other two programs.
 */
void escape_string(const char* source, char *target, int maxlen)
{
	int	i;
	char	*optr;

	optr = target;
	for (i = 0; i < maxlen; i++)
	{
		if ('\\' == source[i])
		{
			snprintf(optr, 3, "\\\\");
			optr += 2;
		} else if ('\n' == source[i])
		{
			snprintf(optr, 3, "\\n");
			optr += 2;
		} else if ('\0' == source[i])
		{
			snprintf(optr, 3, "\\0");
			optr += 2;
		} else
		{
			*(optr++) = source[i];
		}
	}
}

/* Creates listener TCP socket, starts listening for connections,
 * opens log file for logging, and finally starts accepting connections.
 * Run program with:
 *      ./program <logfile> <portno>
 *
 * params:
 *      @logfile file path of output audit log
 *      @portno port number to listen on
 * returns:
 *      1 if program executed successfully and exited (terminated)
 *      0 if something went wrong and program exited
 */
int main(int argc, char *argv[])
{
	int			listen_sockfd, client_sockfd;
        int			accepted = 0, bytes_recv, msg_size = 0;
	char			date[101], buf[BUF_SIZE], escaped[2 * BUF_SIZE];
	struct sockaddr_in6	src, servaddr;
	socklen_t		srclen;
	time_t			curtime;
	struct tm		*timeptr;
	struct sigaction	listener_term_handler;

	if (3 != argc)
	{
		fprintf(stderr, "Usage: %s <logfile> <portno>\n", argv[PROGNAME]);
		return 0;
	}
	/* Open log file for logging */
	if (1 != open_logfile(argv[LOGFILE]))
		return 0;	/* Something went wrong when opening log file */
        terminate = 0;
	/* Set signal handler */
	memset(&listener_term_handler, 0, sizeof(struct sigaction));
	listener_term_handler.sa_handler = listener_signal_handler;
	listener_term_handler.sa_flags = 0;
	sigaction(SIGINT, &listener_term_handler, NULL);	/* Handle Ctrl + C */
	sigaction(SIGTERM, &listener_term_handler, NULL);	/* Handle kill -15 */
	/* Create socket to start listening */
	listen_sockfd = socket(AF_INET6, SOCK_STREAM, 0);
	if (-1 == listen_sockfd)
	{
		perror("socket");
		return 0;
	}
	/* Initialize address to bind the socket to */
	memset(&servaddr, 0, sizeof(servaddr));
	servaddr.sin6_family = AF_INET6;
	servaddr.sin6_port = htons(atoi(argv[PORTNO]));
	memcpy(&servaddr.sin6_addr, &in6addr_any, sizeof(in6addr_any));
	if (0 != bind(listen_sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)))
	{
		perror("bind");
		return 0;
	}
	if (0 != listen(listen_sockfd, BACKLOG))
	{
		perror("listen");
		return 0;
	}
        while (!terminate)
	{
		if (!accepted)
		{	/* If we have not accepted a connection, then attempt to accept one */
			srclen = sizeof(src);
			client_sockfd = accept(listen_sockfd, (struct sockaddr *)&src, &srclen);
			if (0 > client_sockfd)
			{
				if (EINTR != errno)
					perror("accept");
				continue;
			}
			accepted = 1;
		}
		msg_size = 0;
		/* TCP sockets may take several recv's to get the entire message */
		while (0 < (bytes_recv = recv(client_sockfd, buf + msg_size, BUF_SIZE - msg_size - 1, 0)))
			msg_size += bytes_recv;
		if (0 < msg_size)
		{	/* We've received message from client, log it */
                        buf[msg_size] = '\0';
			time(&curtime);
			timeptr = gmtime(&curtime);
			strftime(date, 100, "%Y-%m-%d %H:%M:%S", timeptr);
			memset(escaped, 0, sizeof(escaped));
			escape_string(buf, escaped, msg_size);
			fprintf(stderr, "%s; %s\n", date, buf);
		}
		/* Client disconnected or closed socket */
		close(client_sockfd);
		accepted = 0;
	}
	close(listen_sockfd);
	return 1;
}
