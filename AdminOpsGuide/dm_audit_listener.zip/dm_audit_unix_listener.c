/****************************************************************
 *								*
 * Copyright (c) 2018-2019 Fidelity National Information	*
 * Services, Inc. and/or its subsidiaries. All rights reserved.	*
 *								*
 *	This source code contains the intellectual property	*
 *	of its copyright holder(s), and is made available	*
 *	under a license.  If you do not know the terms of	*
 *	the license, please stop and do not read further.	*
 *								*
 ****************************************************************/

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_BUF_SIZE	2048	/* For testing/demo purposes, we'll keep this at a lower number */
#define	BACKLOG		10	/* Maximum length to which the queue of pending connections for socket may grow */
/* Parameter Numbers */
#define	PROGNAME	0
#define	LOGFILE		1
#define	SOCKFILE	2

char	logfile[PATH_MAX + 1];
int	terminate;              /* Boolean value set by signal handler to let program know to terminate */

/* Handler for SIGINT and SIGTERM caused by Ctrl-C and kill (-15) respectively.
 *
 * params:
 * 	@sig signal number
 *
 * MAINTENANCE NOTE: This function also exists in dm_audit_tcp_listener.c and dm_audit_tls_listener.c.
 *	If changes are made here, then they should also be made in the other two programs.
 */
void listener_signal_handler(int sig)
{
	terminate = 1;
	return;
}

/* Opens a file and dup its file descriptor to stdout and stderr
 *
 * params:
 * 	@where file path of output audit log file
 * returns:
 *	1 if log file opened and dup'ed successfully
 *	0 if something went wrong
 *
 * MAINTENANCE NOTE: This function also exists in dm_audit_tcp_listener.c and dm_audit_tls_listener.c.
 *	If changes are made here, then they should also be made in the other two programs.
 */
int open_logfile(char *where)
{
	int	logfd;

	if (NULL != where)
	{
		memset(logfile, 0, PATH_MAX + 1);
		strncpy(logfile, where, PATH_MAX);
	}
	if (strlen(logfile))
	{
		logfd = open(logfile, O_WRONLY | O_CREAT | O_APPEND, S_IWUSR | S_IRUSR);
		if (0 > logfd)
		{
			fprintf(stderr, "Failed to open output file %s: %s\n", logfile, strerror(errno));
			return 0;
		}
		dup2(logfd, STDOUT_FILENO);
		dup2(logfd, STDERR_FILENO);
		close(logfd);
		return 1;
	}
	fprintf(stderr, "No log file specified.");
	return 0;
}

/* Escapes all backslashes ('\\'), null characters ('\0'), and newlines ('\n')
 *
 * params:
 * 	@source original string (contains at most "maxlen" characters) to escape
 * 	@target dest string that must contain enough space for at least 2 * "maxlen" characters (if all characters must be escaped)
 * 	@maxlen length of "source" string
 *
 * MAINTENANCE NOTE: This function also exists in dm_audit_tcp_listener.c and dm_audit_tls_listener.c.
 *	If changes are made here, then they should also be made in the other two programs.
 */
void escape_string(const char* source, char *target, int maxlen)
{
	int 	i;
	char 	*optr;

	optr = target;
	for (i = 0; i < maxlen; i++)
	{
		if ('\\' == source[i])
		{
			snprintf(optr, 3, "\\\\");
			optr += 2;
		} else if ('\n' == source[i])
		{
			snprintf(optr, 3, "\\n");
			optr += 2;
		} else if ('\0' == source[i])
		{
			snprintf(optr, 3, "\\0");
			optr += 2;
		} else
		{
			*(optr++) = source[i];
		}
	}
}

/* Loops infinitely, accepts all connections, and logs received messages
 *
 * params:
 * 	@fd file descriptor of socket to accept connections on
 * returns:
 *	1 if finished listening (terminated)
 *	0 if something went wrong
 */
int listen_loop(int fd)
{
	int			clifd, length;
	char			buf[MAX_BUF_SIZE], escaped[2 * MAX_BUF_SIZE], date[101];
	struct sockaddr_un	client = {0};
	struct tm		*timeptr;
	time_t			curtime;
	socklen_t		cli_len;

	while (!terminate)
	{
		cli_len = sizeof(client);
		clifd = accept(fd, (struct sockaddr *) &client, &cli_len);
		if (0 > clifd)
		{
			if (EINTR != errno)
				perror("accept");
			continue;
		}
		length = recv(clifd, buf, sizeof(buf) - 1, 0);
		if (0 < length)
		{	/* Received message from client, so log it */
			time(&curtime);
			timeptr = gmtime(&curtime);
			strftime(date, 100, "%Y-%m-%d %H:%M:%S", timeptr);
			memset(escaped, 0, sizeof(escaped));
			escape_string(buf, escaped, length);
			fprintf(stderr, "%s; %s\n", date, escaped);
		}
		close(clifd);
	}
	return 1;
}

/* Creates listener UNIX socket, starts listening for connections,
 * opens log file for logging, and finally starts accepting connections.
 * Run program with:
 *	./program <logfile> <sockfile>
 *
 * params:
 *	@logfile file path of output audit log
 *	@sockfile file path of unix domain socket file
 * returns:
 *	1 if program executed successfully and exited (should not occur)
 *	0 if something went wrong and program exited
 */
int main (int argc, char *argv[])
{
	int			fd;
	struct sockaddr_un	addr = {0};
	struct sigaction	listener_term_handler;

	if (3 != argc)
	{
		fprintf(stderr, "Usage: %s <logfile> <sockfile>\n", argv[PROGNAME]);
		return 0;
	}
	/* Open log file for logging */
	if (1 != open_logfile(argv[LOGFILE]))
		return 0;	/* Something went wrong when opening log file */
	terminate = 0;
	/* Set signal handler */
	memset(&listener_term_handler, 0, sizeof(struct sigaction));
	listener_term_handler.sa_handler = listener_signal_handler;
	listener_term_handler.sa_flags = 0;
	sigaction(SIGINT, &listener_term_handler, NULL);	/* Handle Ctrl + C */
	sigaction(SIGTERM, &listener_term_handler, NULL);	/* Handle kill -15 */
	/* Create socket to start listening */
	fd = socket(AF_UNIX, SOCK_STREAM, 0);
	if (-1 == fd)
	{
		perror("Failed to create socket");
		return 0;
	}
	addr.sun_family = AF_UNIX;
	strncpy(addr.sun_path, argv[SOCKFILE], sizeof(addr.sun_path) - 1);
	unlink(argv[SOCKFILE]);
	if (-1 == bind(fd, (struct sockaddr *)&addr, sizeof(addr)))
	{
		fprintf(stderr, "Failed to bind socket %s: %s\n", argv[SOCKFILE], strerror(errno));
		return 0;
	}
	chmod(argv[SOCKFILE], 0666);
	if (-1 == listen(fd, BACKLOG))
	{
		perror("Failed to listen");
		return 0;
	}
	if (1 != listen_loop(fd))
		return 0;
	close(fd);
	return 1;
}
