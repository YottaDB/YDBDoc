/****************************************************************
 *								*
 * Copyright (c) 2022 Fidelity National Information		*
 * Services, Inc. and/or its subsidiaries. All rights reserved.	*
 *								*
 *	This source code contains the intellectual property	*
 *	of its copyright holder(s), and is made available	*
 *	under a license.  If you do not know the terms of	*
 *	the license, please stop and do not read further.	*
 *								*
 ****************************************************************/
#define	PROGNAME		0
#define MAX_BUF_SIZE		2048		/* For testing/demo purposes. Adjust as per the message size in your environment. */
#define	BACKLOG			10		/* Maximum length to which the queue of pending connections for socket may grow */
#define TIME_FORMAT     	"_%Y%j%H%M%S"   /* .yearjuliendayhoursminutesseconds */
#define	LOGFILE			1
/* Local Socket */
#define	SOCKFILE		2
/* TCP */
#define	PORTNO			2
/* TLS/SSL  */
#define	VERIFY_DEPTH		7		/* TLS certificate verification depth */
#define SESSION_ID_DEFAULT	"audit_logger"	/* Default TLS session ID */
#define	ARG_CLICERT		"CLICERT"
#define	ARG_CAFILE		"CAFILE"
#define	ARG_CAPATH		"CAPATH"
#define	CERTFILE		3
#define	PRIVKEYFILE		4
#define	PASSPHRASE		5
#define	NUM_REQUIRED_ARGS	6		/* Number of required command line arguments for TLS*/
char 	*pass;					/* Used to store the TLS/SSL certificate passphrase */
/* Common */
char	logfile[PATH_MAX + 1];
int	terminate = 0;				/* Boolean value set by signal handler to let program know to terminate */
int 	logfileswitch = 0;			/* Boolean value set by signal handler to let program know to switch
						   the log file */
int	logfd;
